const pricingData = [
    {
        icon: 'ri-edit-box-line',
        title: 'Starter',
        price: 19,
    },
    {
        icon: 'ri-medal-line ',
        title: 'Professional',
        price: 29,
    },
    {
        icon: 'ri-stack-line',
        title: 'Enterprise',
        price: 39,
    }, {
        icon: 'ri-vip-crown-line',
        title: 'Unlimited',
        price: 49,
    }
];

export { pricingData };
