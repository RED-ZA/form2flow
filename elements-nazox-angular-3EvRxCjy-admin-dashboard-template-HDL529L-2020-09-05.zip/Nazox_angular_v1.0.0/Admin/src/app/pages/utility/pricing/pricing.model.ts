export interface Price {
    icon: string;
    title: string;
    price: number;
}

