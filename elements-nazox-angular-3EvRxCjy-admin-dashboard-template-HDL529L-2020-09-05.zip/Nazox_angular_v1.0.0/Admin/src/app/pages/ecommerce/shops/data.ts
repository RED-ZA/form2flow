const shopsData = [
    {
        image: 'assets/images/companies/img-1.png',
        title: 'Nedick\'s',
        name: 'Wayne McClain',
        products: 86,
        balance: '$12,456'
    },
    {
        image: 'assets/images/companies/img-2.png',
        title: 'Brendle\'s',
        name: 'David Marshall',
        products: 72,
        balance: '$10,352'
    },
    {
        image: 'assets/images/companies/img-3.png',
        title: 'Tech Hifi',
        name: 'Katia Stapleton',
        products: 75,
        balance: '$9,963'
    },
    {
        image: 'assets/images/companies/img-4.png',
        title: 'Lafayette',
        name: 'Andrew Bivens',
        products: 65,
        balance: '$14,568'
    },
    {
        image: 'assets/images/companies/img-5.png',
        title: 'Packer',
        name: 'Mae Rankin',
        products: 82,
        balance: '$16,445'
    },
    {
        image: 'assets/images/companies/img-6.png',
        title: 'Micro Design',
        name: ' Brian Correa',
        products: 71,
        balance: '$11,523'
    },
    {
        image: 'assets/images/companies/img-7.png',
        title: 'Keeney\'s',
        name: 'Dean Odom',
        products: 66,
        balance: '$13,478'
    },
    {
        image: 'assets/images/companies/img-8.png',
        title: 'Tech Hifi',
        name: 'John McLeroy',
        products: 58,
        balance: '$14,654'
    }
];

export { shopsData };
