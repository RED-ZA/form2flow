export interface Customers {
    name: string;
    email: string;
    phone: string;
    balance: string;
    date: string;
}
